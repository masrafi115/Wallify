package com.codesw.wallify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.app.Activity;
import android.content.SharedPreferences;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import androidx.palette.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class FavoritesFragmentActivity extends  Fragment  { 
	
	
	private double key = 0;
	
	private ArrayList<HashMap<String, Object>> Favorites = new ArrayList<>();
	
	private LinearLayout linear1;
	private GridView grid;
	
	private SharedPreferences favourites;
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.favorites_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		com.google.firebase.FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
		grid = (GridView) _view.findViewById(R.id.grid);
		favourites = getContext().getSharedPreferences("favourites", Activity.MODE_PRIVATE);
	}
	
	private void initializeLogic() {
		grid.setNumColumns(2); 
		grid.setColumnWidth(GridView.AUTO_FIT); 
		grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); 
		grid.setVerticalScrollBarEnabled(false); 
		_getData();
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _getData () {
		grid.setAdapter(new GridAdapter(Favorites));
		((BaseAdapter)grid.getAdapter()).notifyDataSetChanged();
	}
	
	
	public class GridAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public GridAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom, null);
			}
			
			final CardView cardview1 = (CardView) _view.findViewById(R.id.cardview1);
			
			Glide.with(getContext()).load(Uri.parse(_data.get((int)_position).get("url").toString())).into(imageview2);
			imageview3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					Favorites.remove((int)(_position));
					favourites.edit().putString(String.valueOf((long)(key)), new Gson().toJson(Favorites)).commit();
				}
			});
			
			return _view;
		}
	}
	
	
}