package com.codesw.wallify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import com.bumptech.glide.Glide;
import android.graphics.Typeface;
import androidx.palette.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class HomeFragmentActivity extends  Fragment  { 
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ArrayList<HashMap<String, Object>> Favorites = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> Wallpapers = new ArrayList<>();
	
	private GridView grid;
	
	private DatabaseReference Palabra_clave = _firebase.getReference("Palabra_clave");
	private ChildEventListener _Palabra_clave_child_listener;
	private SharedPreferences favourites;
	private Intent i = new Intent();
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.home_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		com.google.firebase.FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		
		grid = (GridView) _view.findViewById(R.id.grid);
		favourites = getContext().getSharedPreferences("favourites", Activity.MODE_PRIVATE);
		
		_Palabra_clave_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				Wallpapers.add(_childValue);
				_refresh();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Palabra_clave.addChildEventListener(_Palabra_clave_child_listener);
	}
	
	private void initializeLogic() {
		grid.setNumColumns(2); 
		grid.setColumnWidth(GridView.AUTO_FIT); 
		grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); 
		grid.setVerticalScrollBarEnabled(false); 
		_refresh();
	}
	
	@Override
	public void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _refresh () {
		grid.setAdapter(new GridAdapter(Wallpapers));
		((BaseAdapter)grid.getAdapter()).notifyDataSetChanged();
	}
	
	
	public class GridAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public GridAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom, null);
			}
			
			final CardView cardview1 = (CardView) _view.findViewById(R.id.cardview1);
			
			textview1.setText(Wallpapers.get((int)_position).get("Palabra_clave").toString());
			Glide.with(getContext()).load(Uri.parse(Wallpapers.get((int)_position).get("Fondo").toString())).into(imageview2);
			textview1.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"fonts/manrope_bold.ttf"), 0);
			cardview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getContext(), ViewActivity.class);
					i.putExtra("img_url", Wallpapers.get((int)_position).get("Fondo").toString());
					i.putExtra("categories", Wallpapers.get((int)_position).get("Palabra_clave").toString());
					i.putExtra("author", Wallpapers.get((int)_position).get("Autor").toString());
					startActivity(i);
				}
			});
			
			return _view;
		}
	}
	
	
}