package com.codesw.wallify;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Switch;
import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.CompoundButton;
import androidx.palette.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class SettingsActivity extends  AppCompatActivity  { 
	
	
	private String variable = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<String> ls = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview1;
	private TextView textview3;
	private LinearLayout linear3;
	private LinearLayout linear30;
	private TextView textview23;
	private LinearLayout linear2;
	private LinearLayout linear31;
	private LinearLayout linear4;
	private LinearLayout linear15;
	private ImageView imageview1;
	private TextView textview14;
	private LinearLayout linear28;
	private Switch switch1;
	private TextView textview18;
	private TextView textview19;
	private LinearLayout linear29;
	private Switch switch2;
	private TextView textview20;
	private TextView textview21;
	private TextView textview11;
	private LinearLayout linear16;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear10;
	private LinearLayout linear8;
	private LinearLayout linear11;
	private LinearLayout linear9;
	private LinearLayout linear12;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private TextView textview8;
	private TextView textview9;
	private TextView textview10;
	private TextView textview12;
	private TextView textview13;
	
	private SharedPreferences setting;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		textview23 = (TextView) findViewById(R.id.textview23);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview14 = (TextView) findViewById(R.id.textview14);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		switch1 = (Switch) findViewById(R.id.switch1);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview19 = (TextView) findViewById(R.id.textview19);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		switch2 = (Switch) findViewById(R.id.switch2);
		textview20 = (TextView) findViewById(R.id.textview20);
		textview21 = (TextView) findViewById(R.id.textview21);
		textview11 = (TextView) findViewById(R.id.textview11);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		textview5 = (TextView) findViewById(R.id.textview5);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview13 = (TextView) findViewById(R.id.textview13);
		setting = getSharedPreferences("setting", Activity.MODE_PRIVATE);
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					
					linear1.setBackgroundColor(0xFF000000);
					switch1.setTextColor(0xFFFFFFFF);
					switch2.setTextColor(0xFFFFFFFF);
					
				}
				else {
					
					linear1.setBackgroundColor(0xFFFFFFFF);
					switch1.setTextColor(0xFF000000);
					switch2.setTextColor(0xFF000000);
					
				}
			}
		});
		
		switch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				
			}
		});
	}
	
	private void initializeLogic() {
		_Elevation(linear3, 5);
		_changeActivityFont("manrope_bold");
		if (setting.getString("night", "").equals("activated")) {
			switch1.setChecked(true);
			linear1.setBackgroundColor(0xFFFFFFFF);
			switch1.setTextColor(0xFF000000);
			switch2.setTextColor(0xFF000000);
		}
		else {
			if (setting.getString("night", "").equals("deactivated")) {
				switch1.setChecked(false);
				linear1.setBackgroundColor(0xFF000000);
				switch1.setTextColor(0xFFFFFFFF);
				switch2.setTextColor(0xFFFFFFFF);
			}
		}
		if (setting.getString("", "").equals("true")) {
			switch2.setChecked(true);
		}
		else {
			switch2.setChecked(false);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	public void _changeActivityFont (final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					((TextView) v).setTypeface(typeace);
				}
				else {
					if ((v instanceof EditText )) {
						((EditText) v).setTypeface(typeace);
					}
					else {
						if ((v instanceof Button)) {
							((Button) v).setTypeface(typeace);
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}